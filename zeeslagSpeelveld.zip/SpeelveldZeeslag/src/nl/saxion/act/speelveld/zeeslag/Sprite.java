package nl.saxion.act.speelveld.zeeslag;

public class Sprite {

	/*
	 * Voor in de toekomst
	 * nog niet bekend wat hier mee gaat gebeuren
	 * in de tussentijd worden placeholders gebruikt
	 * in de vorm van background colors
	 */
}
