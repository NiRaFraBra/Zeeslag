package nl.saxion.act.speelveld.zeeslag;

import android.R.integer;
import android.R.string;
import nl.saxion.act.playground.model.GameBoard;

public class ZeeslagBoard extends GameBoard {

	private static final int GAMEBOARD_WIDTH = 10;
	private static final int GAMEBOARD_HEIGHT = 12;
	
	public ZeeslagBoard(){
		super(GAMEBOARD_WIDTH, GAMEBOARD_HEIGHT);
	}
	
	public void onEmptyTileClicked(int x, int y){
		
	}
	
	public String getBackgroundImg(int mx, int my){
		return null;
	}
	
	/*
	 * (?) lijst van coordinaten
	 * object van speler (dit word het bord van de speler)
	 * object van tegenstander (dit word het bord van de tegenstander)
	 * methode boten plaatsen (op t bord)
	 * methode bommen plaatsen (op t bord)
	 * methode clear bord (het bord leeghalen en alles van de het andere bord weergeven)
	 */
	
}
