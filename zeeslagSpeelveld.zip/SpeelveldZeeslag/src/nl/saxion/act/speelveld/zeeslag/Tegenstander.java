package nl.saxion.act.speelveld.zeeslag;

public class Tegenstander {

	/*
	 * lijst van boten 
	 * een methode die automatisch boten plaatst
	 * een methode die automatisch bommen plaatst
	 * 
	 */
	
}
