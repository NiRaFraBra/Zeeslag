package nl.saxion.act.speelveld.zeeslag;

public class Co�rdinaat {

	/*
	 * integer x as
	 * integer y as
	 */
}
