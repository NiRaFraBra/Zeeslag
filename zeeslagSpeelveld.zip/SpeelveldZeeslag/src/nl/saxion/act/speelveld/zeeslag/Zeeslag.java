package nl.saxion.act.speelveld.zeeslag;

import android.R.integer;
import nl.saxion.act.playground.model.Game;
import nl.saxion.act.playground.model.GameBoard;

public class Zeeslag extends Game {
	private static final String TAG = "GameView";
	
	private MainActivity activity;
	
	private int score;
	
	public Zeeslag(MainActivity activity) {
		super(new ZeeslagBoard());

		this.activity = activity;
		
		ZeeslagBoardView gameView = activity.getGameBoardView();
		GameBoard gameBoard = getGameBoard();
		gameView.setGameBoard(gameBoard);
		
		gameView.setFixedGridSize(gameBoard.getWidth(),gameBoard.getHeight());
				
		
	}
	
	/*
	 * (?) lijst van co�rdinaten (gebruik class co�rdinaat)
	 * gameBoard van speler (switchen naar speler)
	 * gameBoard van computer (switchen naar computer)
	 * methode die scherm wisselt (maakt gebruik van gameboards)
	 * method (timer) die er voor zorgt dat er tijd tussen de stappen zit
	 */
	
	

}
