package nl.saxion.act.speelveld.zeeslag;

import android.app.Activity;
import android.widget.TextView;
import nl.saxion.act.playground.R;
import nl.saxion.act.playground.model.GameObject;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {

	private Zeeslag zeeslag;
	private ZeeslagBoardView zeeslagView;
	private TextView scoreLabel;
	
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);
		
		
		zeeslagView = (ZeeslagBoardView) findViewById(R.id.game);
		scoreLabel = (TextView) findViewById(R.id.scoreTextView);
		
		zeeslag = new Zeeslag(this);
		
	}
	
	public ZeeslagBoardView getGameBoardView(){
		return zeeslagView;
	}
	
}
