package nl.saxion.act.speelveld.zeeslag;

import nl.saxion.act.playground.R;
import android.content.Context;
import android.util.AttributeSet;
import android.util.Log;
import nl.saxion.act.playground.view.GameBoardView;
import nl.saxion.act.playground.view.SpriteCache;

public class ZeeslagBoardView extends GameBoardView{
	private static final String TAG = "GameView";
	
	public ZeeslagBoardView(Context context, AttributeSet attrs){
		super(context, attrs);
		initGameView();
	}
	
	public ZeeslagBoardView(Context context, AttributeSet attrs, int defStyle){
		super(context, attrs, defStyle);
		initGameView();
	}
	
	private void initGameView(){
		Log.d(TAG, "Loading all images");
		
		SpriteCache spriteCache = SpriteCache.getInstance();
		spriteCache.setContext(this.getContext());
		
		spriteCache.loadTile("empty", R.drawable.cell);
		setEmptyTile("empty");
	}
}
