package nl.saxion.act.speelveld.zeeslag;

public class Speler {

	/*
	 * lijst van boten 
	 * een methode die boten plaatst
	 * een methode die bommen plaatst
	 * een integer met de score
	 * een integer met de hits
	 * een integer met de misses
	 * hitpercentage als double
	 */
	
}
