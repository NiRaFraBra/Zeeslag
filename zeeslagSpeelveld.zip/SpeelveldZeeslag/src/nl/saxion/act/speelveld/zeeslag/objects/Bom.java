package nl.saxion.act.speelveld.zeeslag.objects;

import nl.saxion.act.playground.model.GameBoard;
import nl.saxion.act.playground.model.GameObject;

public class Bom extends GameObject {

	@Override
	public String getImageId() {
		return null;
	}

	@Override
	public void onTouched(GameBoard gameBoard) {
	}

	/*
	 * een sprite van de class Sprite (in toekomst, geen prioriteit) gebruik een background color als placeholder
	 * een cooordinaat (class Coordinaat) als een object
	 */
	
}
